package com.hms.hospital_management.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users1")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;

    @Column(nullable = false, unique = true)
    private String email; // ✅ Used as username (for login)

    @Column(nullable = false)
    private String password;

    private int age;

    private String gender; // Male, Female, Other

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "user_conditions", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "medical_condition") // ✅ FIXED: avoid using reserved keyword
    private Set<String> conditions = new HashSet<>(); // e.g., Diabetic, Blood Pressure

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();
}
