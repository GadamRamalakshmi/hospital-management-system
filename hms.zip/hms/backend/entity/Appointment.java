package com.hms.hospital_management.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- Patient Info ---
    private String patientEmail;         // link to User table by email
    private String patientName;
    private int age;
    private String gender;

    private boolean diabetic;
    private boolean bp;

    // --- Specialist & Slot Info ---
    private String specialist;
    private String slot;                 // e.g., "10:00 AM", "Emergency"
    private boolean isFlexible;

    // --- Doctor Info ---
    private String doctorName;
    private String doctorSpecialization;

    // --- Date/Time ---
    private LocalDate date;
    private LocalTime time;

    // --- Appointment Status ---
    private boolean emergency;           // if true, use emergency reserved slot
    private boolean preponedOrPostponed;

    private String status;               // PENDING, COMPLETED, CANCELLED
    private String prescription;

    // --- Uploaded Medical Record ---
    private String reportName;           // filename (e.g. xray.pdf)

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] reportData;           // file binary (optional, or use file path/S3)

}
