package com.hms.hospital_management.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String specialization; // e.g., Cardiologist, Neurologist

    private String availableDays;  // e.g., "Mon,Tue,Fri"

    private String availableTime;  // e.g., "10:00-17:00"
}
