package com.hms.hospital_management.repository;

import com.hms.hospital_management.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    // ✅ All appointments by patient (used in history or future features)
    List<Appointment> findByPatientEmail(String email);

    // ✅ Latest appointment for PatientDashboard
    Optional<Appointment> findTopByPatientEmailOrderByDateDesc(String email);

    // ✅ Appointments by doctor name for today’s queue
    List<Appointment> findByDoctorNameAndDate(String doctorName, LocalDate date);

    // ✅ Appointments on a specific date (used in queue system)
    List<Appointment> findByDate(LocalDate date);

    // ✅ Appointments by status (e.g., "PENDING", "COMPLETED")
    List<Appointment> findByStatus(String status);

    // ✅ All emergency appointments for today
    List<Appointment> findByEmergencyTrueAndDate(LocalDate date);
}
