package com.hms.hospital_management.dto;

import lombok.Data;

@Data
public class EmergencySlotRequest {
    private String patientName;
    private String patientEmail;
    private int age;
    private boolean diabetic;
    private boolean bp;
    private String gender;
    private String doctorName;
    private String doctorSpecialization;
}
