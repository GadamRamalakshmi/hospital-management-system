package com.hms.hospital_management.dto;

import lombok.Data;
import java.util.Set;

@Data
public class RegisterRequest {
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private int age;
    private String gender;
    private Set<String> conditions; // e.g., ["Diabetic", "Blood Pressure"]
}
