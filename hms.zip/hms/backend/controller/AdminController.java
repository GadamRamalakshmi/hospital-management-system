package com.hms.hospital_management.controller;

import com.hms.hospital_management.entity.Appointment;
import com.hms.hospital_management.entity.Doctor;
import com.hms.hospital_management.entity.User;
import com.hms.hospital_management.repository.AppointmentRepository;
import com.hms.hospital_management.repository.DoctorRepository;
import com.hms.hospital_management.repository.UserRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final DoctorRepository doctorRepository;
    private final UserRepository userRepository;
    private final AppointmentRepository appointmentRepository;

    // ============================
    // 🔧 DOCTOR MANAGEMENT
    // ============================

    @GetMapping("/doctors")
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        return ResponseEntity.ok(doctorRepository.findAll());
    }

    @PostMapping("/doctors")
    public ResponseEntity<Doctor> addDoctor(@RequestBody Doctor doctor) {
        return ResponseEntity.ok(doctorRepository.save(doctor));
    }

    @PutMapping("/doctors/{id}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable Long id, @RequestBody Doctor updatedDoctor) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        doctor.setName(updatedDoctor.getName());
        doctor.setSpecialization(updatedDoctor.getSpecialization());
        doctor.setAvailableDays(updatedDoctor.getAvailableDays());
        doctor.setAvailableTime(updatedDoctor.getAvailableTime());

        return ResponseEntity.ok(doctorRepository.save(doctor));
    }

    @DeleteMapping("/doctors/{id}")
    public ResponseEntity<String> deleteDoctor(@PathVariable Long id) {
        doctorRepository.deleteById(id);
        return ResponseEntity.ok("Doctor removed successfully");
    }

    // ============================
    // 👤 PATIENT MANAGEMENT
    // ============================

    @GetMapping("/patients")
    public ResponseEntity<List<User>> getAllPatients() {
        return ResponseEntity.ok(
                userRepository.findAll()
                        .stream()
                        .filter(user -> user.getRoles().stream()
                                .anyMatch(role -> role.getName().equals("ROLE_PATIENT")))
                        .toList()
        );
    }

    // ============================
    // ⏱ PATIENT QUEUE (Today)
    // ============================

    @GetMapping("/queue")
    public ResponseEntity<List<Appointment>> getTodayQueue() {
        List<Appointment> queue = appointmentRepository.findByDate(LocalDate.now())
                .stream()
                .sorted((a1, a2) -> {
                    if (a1.isEmergency() && !a2.isEmergency()) return -1;
                    if (!a1.isEmergency() && a2.isEmergency()) return 1;
                    return a1.getTime().compareTo(a2.getTime());
                })
                .toList();

        return ResponseEntity.ok(queue);
    }
}
