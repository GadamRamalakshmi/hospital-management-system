package com.hms.hospital_management.controller;

import com.hms.hospital_management.service.AISymptomService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AIController {

    private final AISymptomService aiSymptomService;

    @GetMapping("/suggest-specialist")
    public ResponseEntity<?> suggestSpecialist(
            @RequestParam String symptom,
            @RequestParam boolean diabetic,
            @RequestParam boolean bp
    ) {
        String specialist = aiSymptomService.getSuggestedSpecialist(symptom, diabetic, bp);
        return ResponseEntity.ok(specialist);
    }
}
