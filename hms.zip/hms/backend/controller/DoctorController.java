package com.hms.hospital_management.controller;

import com.hms.hospital_management.dto.EmergencySlotRequest;
import com.hms.hospital_management.entity.Appointment;
import com.hms.hospital_management.repository.AppointmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@RestController
@RequestMapping("/api/doctor")
@RequiredArgsConstructor
public class DoctorController {

    private final AppointmentRepository appointmentRepository;

    // ✅ 1. Get today's appointments (queue)
    @GetMapping("/appointments")
    public ResponseEntity<List<Appointment>> getTodayAppointments(@RequestParam String doctorName) {
        List<Appointment> appointments = appointmentRepository.findByDoctorNameAndDate(doctorName, LocalDate.now());
        return ResponseEntity.ok(appointments);
    }

    // ✅ 2. Mark appointment as complete & add prescription
    @PutMapping("/appointments/{id}/complete")
    public ResponseEntity<Appointment> completeAppointment(
            @PathVariable Long id,
            @RequestParam String prescription
    ) {
        Appointment appt = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        appt.setStatus("COMPLETED");
        appt.setPrescription(prescription);

        return ResponseEntity.ok(appointmentRepository.save(appt));
    }

    // ✅ 3. Manually mark an emergency slot
    @PostMapping("/emergency-slot")
    public ResponseEntity<Appointment> markEmergencySlot(@RequestBody EmergencySlotRequest request) {
        Appointment emergency = Appointment.builder()
                .patientName(request.getPatientName())
                .patientEmail(request.getPatientEmail())
                .age(request.getAge())                     // ✅ fixed instance method call
                .diabetic(request.isDiabetic())
                .bp(request.isBp())
                .gender(request.getGender())
                .doctorName(request.getDoctorName())
                .doctorSpecialization(request.getDoctorSpecialization())
                .date(LocalDate.now())
                .time(LocalTime.of(9, 0)) // fixed slot
                .status("PENDING")
                .emergency(true)
                .build();

        return ResponseEntity.ok(appointmentRepository.save(emergency));
    }
}
