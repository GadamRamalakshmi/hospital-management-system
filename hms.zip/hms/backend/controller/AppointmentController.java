package com.hms.hospital_management.controller;

import com.hms.hospital_management.entity.Appointment;
import com.hms.hospital_management.service.AppointmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@RequiredArgsConstructor
public class AppointmentController {

    private final AppointmentService appointmentService;

    // ✅ Book appointment (with file upload)
    @PostMapping("/book")
    public ResponseEntity<Appointment> bookAppointment(
            @RequestParam String patientName,
            @RequestParam int age,
            @RequestParam String gender,
            @RequestParam boolean diabetic,
            @RequestParam boolean bp,
            @RequestParam String specialist,
            @RequestParam String slot,
            @RequestParam boolean isFlexible,
            @RequestParam(required = false) MultipartFile report // optional file upload
    ) {
        Appointment appointment = appointmentService.bookAppointmentWithFile(
                patientName, age, gender, diabetic, bp, specialist, slot, isFlexible, report
        );
        return ResponseEntity.ok(appointment);
    }

    // ✅ Get patient appointments
    @GetMapping("/patient")
    public ResponseEntity<List<Appointment>> getByPatient(@RequestParam String email) {
        return ResponseEntity.ok(appointmentService.getAppointmentsByPatientEmail(email));
    }

    // ✅ Doctor: Get today's queue
    @GetMapping("/doctor")
    public ResponseEntity<List<Appointment>> getForDoctor(@RequestParam String doctorName) {
        return ResponseEntity.ok(appointmentService.getAppointmentsForDoctorToday(doctorName));
    }

    // ✅ Mark as completed
    @PutMapping("/complete/{id}")
    public ResponseEntity<Appointment> markCompleted(
            @PathVariable Long id,
            @RequestParam String prescription
    ) {
        return ResponseEntity.ok(appointmentService.markAsCompleted(id, prescription));
    }

    // ✅ Cancel appointment
    @DeleteMapping("/cancel/{id}")
    public ResponseEntity<String> cancel(@PathVariable Long id) {
        appointmentService.cancelAppointment(id);
        return ResponseEntity.ok("Cancelled");
    }
}
