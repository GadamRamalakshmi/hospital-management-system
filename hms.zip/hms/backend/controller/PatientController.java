package com.hms.hospital_management.controller;

import com.hms.hospital_management.entity.Appointment;
import com.hms.hospital_management.service.AppointmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/patient")
@RequiredArgsConstructor
public class PatientController {

    private final AppointmentService appointmentService;

    // ✅ 1. Get current appointment by email
    @GetMapping("/appointment")
    public ResponseEntity<?> getAppointment(@RequestParam String email) {
        Appointment appt = appointmentService.getAppointmentByPatientEmail(email);

        if (appt != null) {
            return ResponseEntity.ok(appt);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("message", "No active appointment found.");
        return ResponseEntity.ok(response);
    }

    // ✅ 2. Cancel appointment by ID
    @DeleteMapping("/appointment/{id}")
    public ResponseEntity<?> cancelAppointment(@PathVariable Long id) {
        boolean cancelled = appointmentService.cancelAppointment(id);

        Map<String, Object> response = new HashMap<>();
        if (cancelled) {
            response.put("message", "Appointment cancelled successfully.");
            return ResponseEntity.ok(response);
        } else {
            response.put("error", "Unable to cancel appointment. It may not exist.");
            return ResponseEntity.badRequest().body(response);
        }
    }
}
