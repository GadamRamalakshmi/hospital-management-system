package com.hms.hospital_management.service;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AISymptomService {

    private static final Map<String, String> symptomToSpecialistMap = new HashMap<>();

    static {
        symptomToSpecialistMap.put("fever", "General Physician");
        symptomToSpecialistMap.put("chest pain", "Cardiologist");
        symptomToSpecialistMap.put("headache", "Neurologist");
        symptomToSpecialistMap.put("skin rash", "Dermatologist");
        symptomToSpecialistMap.put("diabetes", "Endocrinologist");
        symptomToSpecialistMap.put("high blood pressure", "Cardiologist");
        symptomToSpecialistMap.put("vision problems", "Ophthalmologist");
        // More mappings
    }

    public String getSuggestedSpecialist(String symptomInput, boolean diabetic, boolean bp) {
        if (diabetic && bp) return "General Physician";
        if (diabetic) return "Endocrinologist";
        if (bp) return "Cardiologist";

        String key = symptomInput.trim().toLowerCase();
        return symptomToSpecialistMap.getOrDefault(key, "General Physician");
    }
}
