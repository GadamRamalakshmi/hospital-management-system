package com.hms.hospital_management.service;

import com.hms.hospital_management.dto.JwtResponse;
import com.hms.hospital_management.dto.LoginRequest;
import com.hms.hospital_management.dto.RegisterRequest;
import com.hms.hospital_management.entity.Role;
import com.hms.hospital_management.entity.User;
import com.hms.hospital_management.repository.RoleRepository;
import com.hms.hospital_management.repository.UserRepository;
import com.hms.hospital_management.util.JwtUtil;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    @PostConstruct
    public void initializeRoles() {
        // Create roles if not present
        if (roleRepository.findByName("ROLE_ADMIN").isEmpty()) {
            roleRepository.save(new Role(null, "ROLE_ADMIN"));
            roleRepository.save(new Role(null, "ROLE_DOCTOR"));
            roleRepository.save(new Role(null, "ROLE_PATIENT"));
        }

        // Create default Admin
        if (userRepository.findByEmail("admin@example.com").isEmpty()) {
            User admin = new User();
            admin.setFirstName("Admin");
            admin.setLastName("User");
            admin.setEmail("admin@example.com");
            admin.setPassword(passwordEncoder.encode("admin123")); // Default password
            admin.setAge(35);
            admin.setGender("Other");
            admin.setConditions(Set.of());

            Role adminRole = roleRepository.findByName("ROLE_ADMIN").get();
            admin.setRoles(Set.of(adminRole));

            userRepository.save(admin);
        }

        // Create default Doctor
        if (userRepository.findByEmail("doctor@example.com").isEmpty()) {
            User doctor = new User();
            doctor.setFirstName("Doctor");
            doctor.setLastName("Strange");
            doctor.setEmail("doctor@example.com");
            doctor.setPassword(passwordEncoder.encode("doctor123")); // Default password
            doctor.setAge(40);
            doctor.setGender("Male");
            doctor.setConditions(Set.of("Diabetic"));

            Role doctorRole = roleRepository.findByName("ROLE_DOCTOR").get();
            doctor.setRoles(Set.of(doctorRole));

            userRepository.save(doctor);
        }
    }


    public String registerPatient(RegisterRequest request) {
        // ✅ Fixed: replaced 'username' with request.getEmail()
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        User user = new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setAge(request.getAge());
        user.setGender(request.getGender());
        user.setConditions(request.getConditions());

        Role patientRole = roleRepository.findByName("ROLE_PATIENT")
                .orElseThrow(() -> new RuntimeException("Role not found"));

        user.getRoles().add(patientRole);
        userRepository.save(user);

        return "Patient registered successfully!";
    }

    public JwtResponse login(LoginRequest request) {
        // Authenticate user via Spring Security
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Set<String> roles = user.getRoles()
                .stream()
                .map(Role::getName)
                .collect(Collectors.toSet());

        String token = jwtUtil.generateToken(user.getEmail(), roles);

        return new JwtResponse(token, user.getEmail(), roles);
    }
}
