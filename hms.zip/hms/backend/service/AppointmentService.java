package com.hms.hospital_management.service;

import com.hms.hospital_management.entity.Appointment;
import com.hms.hospital_management.repository.AppointmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;

    // ✅ 1. Book appointment from direct Appointment object (old method)
    public Appointment bookAppointment(Appointment appointment) {
        if (appointment.isEmergency()) {
            appointment.setTime(LocalTime.of(9, 0));
        } else {
            appointment.setTime(LocalTime.now().plusMinutes(30));
        }
        appointment.setStatus("PENDING");
        return appointmentRepository.save(appointment);
    }

    // ✅ 2. Book appointment using individual fields + optional report file
    public Appointment bookAppointmentWithFile(
            String patientName,
            int age,
            String gender,
            boolean diabetic,
            boolean bp,
            String specialist,
            String slot,
            boolean isFlexible,
            MultipartFile report
    ) {
        Appointment appt = new Appointment();
        appt.setPatientName(patientName);
        appt.setAge(age);
        appt.setGender(gender);
        appt.setDiabetic(diabetic);
        appt.setBp(bp);
        appt.setSpecialist(specialist);
        appt.setSlot(slot);
        appt.setFlexible(isFlexible);
        appt.setDate(LocalDate.now());

        if (slot.equalsIgnoreCase("emergency")) {
            appt.setEmergency(true);
            appt.setTime(LocalTime.of(9, 0));
        } else {
            appt.setTime(LocalTime.now().plusMinutes(30));
        }

        if (report != null && !report.isEmpty()) {
            try {
                appt.setReportName(report.getOriginalFilename());
                appt.setReportData(report.getBytes()); // You can also store file path instead
            } catch (IOException e) {
                throw new RuntimeException("Failed to upload report", e);
            }
        }

        appt.setStatus("PENDING");
        return appointmentRepository.save(appt);
    }

    // ✅ 3. Get current appointment for patient dashboard
    public Appointment getAppointmentByPatientEmail(String email) {
        return appointmentRepository.findTopByPatientEmailOrderByDateDesc(email).orElse(null);
    }

    // ✅ 4. Get all appointments of a patient
    public List<Appointment> getAppointmentsByPatientEmail(String email) {
        return appointmentRepository.findByPatientEmail(email);
    }

    // ✅ 5. Doctor's today's appointments
    public List<Appointment> getAppointmentsForDoctorToday(String doctorName) {
        return appointmentRepository.findByDoctorNameAndDate(doctorName, LocalDate.now());
    }

    // ✅ 6. Mark appointment complete
    public Appointment markAsCompleted(Long appointmentId, String prescription) {
        Appointment appt = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        appt.setStatus("COMPLETED");
        appt.setPrescription(prescription);
        return appointmentRepository.save(appt);
    }

    // ✅ 7. Cancel appointment
    public boolean cancelAppointment(Long appointmentId) {
        Optional<Appointment> optional = appointmentRepository.findById(appointmentId);
        if (optional.isPresent()) {
            appointmentRepository.deleteById(appointmentId);
            return true;
        }
        return false;
    }
}
